import { useEffect, useRef, useState } from 'react'
import { ArrowRight } from '@phosphor-icons/react'

import { wordCount } from '../notes-model.js'
import { paperFields, paperWrite } from './field-model.js'

function remember(snapshot, note, title, body) {
  if (snapshot.current?.id === note.id) {
    snapshot.current.note = note
    snapshot.current.title = title
    snapshot.current.body = body
  }
}

export function FieldSheet({ note, preview, onClose, onCommit, onKeep, onOpenNotes }) {
  const origin = paperFields(note)
  const [title, setTitle] = useState(origin.title)
  const [body, setBody] = useState(origin.body)
  const titleRef = useRef(null)
  const bodyRef = useRef(null)
  const snapshot = useRef(null)
  const previewRef = useRef(preview)
  const commitRef = useRef(onCommit)
  const closeRef = useRef(onClose)
  if (!snapshot.current) snapshot.current = { id: note.id, note, title: origin.title, body: origin.body }
  remember(snapshot, note, title, body)
  previewRef.current = preview
  commitRef.current = onCommit
  closeRef.current = onClose

  function flush(snap = snapshot.current) {
    if (!snap || previewRef.current) return
    const patch = paperWrite(snap.note, snap.title, snap.body)
    if (patch.title === snap.note.title && patch.markdown === snap.note.markdown) return
    commitRef.current(snap.note.id, patch)
  }

  useEffect(() => {
    if (snapshot.current.id !== note.id) {
      flush(snapshot.current)
      const fields = paperFields(note)
      snapshot.current = { id: note.id, note, title: fields.title, body: fields.body }
      setTitle(fields.title)
      setBody(fields.body)
    }
    const focus = window.setTimeout(() => {
      const fields = paperFields(note)
      if (fields.body) bodyRef.current?.focus()
      else titleRef.current?.focus()
    }, 30)
    return () => window.clearTimeout(focus)
  }, [note.id])

  useEffect(() => {
    if (preview) return undefined
    const handle = window.setTimeout(() => flush(), 280)
    return () => window.clearTimeout(handle)
  }, [title, body, preview, note.id])

  useEffect(() => () => flush(), [])

  useEffect(() => {
    const onKey = (event) => {
      if (event.key !== 'Escape') return
      event.preventDefault()
      event.stopPropagation()
      flush()
      closeRef.current()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  const words = wordCount(paperWrite(note, title, body).markdown)
  const tag = note.tags?.[0]

  return (
    <div
      className="field-sheet"
      role="dialog"
      aria-label={title.trim() || 'Open note'}
      onPointerDown={(event) => {
        if (event.target !== event.currentTarget) return
        flush()
        onClose()
      }}
    >
      <article className="field-sheet-paper" onPointerDown={(event) => event.stopPropagation()}>
        <small>{tag ? `#${tag}` : 'A thought'}</small>
        <textarea
          ref={titleRef}
          rows={1}
          className="field-sheet-title"
          aria-label="Title"
          value={title}
          placeholder="A title"
          onChange={(event) => setTitle(event.target.value.replace(/\s*\n\s*/g, ' '))}
          onKeyDown={(event) => {
            if (event.key === 'Enter') {
              event.preventDefault()
              bodyRef.current?.focus()
            }
          }}
        />
        <textarea
          ref={bodyRef}
          aria-label="Note"
          value={body}
          placeholder="The rest can wait."
          onChange={(event) => setBody(event.target.value)}
        />
        <footer>
          <span>{words === 1 ? '1 word' : `${words} words`}</span>
          {preview ? (
            <button type="button" className="primary-button" onClick={() => onKeep(note.id)}>Keep this room</button>
          ) : (
            <button type="button" onClick={() => { flush(); onOpenNotes() }}>Open in Notes <ArrowRight /></button>
          )}
          <button type="button" className="field-sheet-down" onClick={() => { flush(); onClose() }}>Set it down</button>
        </footer>
        {preview && <p className="field-sheet-note">This page is the sample. It is saved only when you keep the room.</p>}
      </article>
    </div>
  )
}
