import { useEffect, useRef, useState } from 'react'
import { flushSync } from 'react-dom'
import { ArrowBendDownLeft, ArrowRight, Check, Plus, PushPin } from '@phosphor-icons/react'

import { FocusEnvironment } from '../Experience.jsx'
import { localDateKey } from '../daily-practice.js'
import { captureThought, excerpt, isActiveNote, updateNote } from '../notes-model.js'
import { appendNextStep, nextSteps, toggleNextStep } from '../next-steps.js'
import { inputActive, timeLabel } from '../lib/ui.js'
import { sampleEvents, sampleNotes } from './field-sample.js'
import { FieldBanner, useReducedMotion } from './FieldChrome.jsx'
import { FieldSheet } from './FieldSheet.jsx'
import { POSE_KEY, clampPose, dayPhase, paperFields, paperPose, phaseCopy, ribbonAt } from './field-model.js'

const HOURS = [['6a', 6], ['9a', 9], ['noon', 12], ['3p', 15], ['6p', 18], ['9p', 21], ['12a', 24]]
const DATE = new Intl.DateTimeFormat('en-US', { weekday: 'long', month: 'long', day: 'numeric' })

function readPoses() {
  try {
    const parsed = JSON.parse(localStorage.getItem(POSE_KEY) || '{}')
    return parsed && typeof parsed === 'object' ? parsed : {}
  } catch {
    return {}
  }
}

/* Today is a spread: the day on the left page, the desk on the right. Both
   read the same notes, steps, events and journal the rest of OSAT keeps. */
export function FieldDesk({ workspace, commit, navigate, today, preview, sampled, onKeep, onBlank, onRemove, sheet, onSheetDone }) {
  const stage = useRef(null)
  const box = useRef(null)
  const reduced = useReducedMotion()
  const [now, setNow] = useState(() => new Date())
  const [draft, setDraft] = useState('')
  const [stepDraft, setStepDraft] = useState('')
  const [freshId, setFreshId] = useState(null)
  const [ghosts, setGhosts] = useState(() => new Set())
  const [arrived] = useState(() => reduced || sessionStorage.getItem('osat.field.arrived') === '1')
  const [poses, setPoses] = useState(readPoses)
  const [compact, setCompact] = useState(false)
  const [focusOpen, setFocusOpen] = useState(false)
  const [openId, setOpenId] = useState(null)
  const [heldId, setHeldId] = useState(null)
  const openRef = useRef(null)
  openRef.current = openId
  const posesRef = useRef(poses)
  posesRef.current = poses

  const phase = dayPhase(now)
  const [greeting, sub] = phaseCopy(phase)
  const realNotes = workspace.notes.filter(isActiveNote)
  const notes = preview ? sampleNotes() : realNotes
  const planId = `daily-plan-${today}`
  const steps = nextSteps(notes)
    .filter((step) => !step.done || ghosts.has(step.id))
    .sort((a, b) => (b.noteId === planId) - (a.noteId === planId))
  const openCount = steps.filter((step) => !step.done).length
  const events = (preview ? sampleEvents() : workspace.calendar.events)
    .filter((event) => localDateKey(new Date(event.start)) === today)
    .sort((a, b) => Date.parse(a.start) - Date.parse(b.start))
  const journal = preview ? null : realNotes.find((note) => note.id === `journal-${today}`)
  const papers = notes
    .filter((note) => !/^(daily-plan|journal)-/.test(note.id))
    .sort((a, b) => Number(Boolean(b.pinned)) - Number(Boolean(a.pinned)) || String(b.updatedAt).localeCompare(String(a.updatedAt)))
    .slice(0, compact ? 6 : 9)
  const sheetNote = notes.find((item) => item.id === openId) || null
  const late = phase === 'evening' || phase === 'night'

  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), 60000)
    return () => window.clearInterval(timer)
  }, [])

  useEffect(() => {
    if (!arrived) sessionStorage.setItem('osat.field.arrived', '1')
  }, [arrived])

  useEffect(() => {
    const node = stage.current
    if (!node) return undefined
    const observer = new ResizeObserver(([entry]) => setCompact(entry.contentRect.width < 640))
    observer.observe(node)
    return () => observer.disconnect()
  }, [])

  /* The lamp drifts a little toward the pointer. */
  useEffect(() => {
    const node = stage.current?.parentElement
    if (!node || reduced) return undefined
    let frame = 0
    let tx = 0
    let ty = 0
    let cx = 0
    let cy = 0
    const onMove = (event) => {
      const rect = node.getBoundingClientRect()
      tx = ((event.clientX - rect.left) / rect.width - 0.5) * 40
      ty = ((event.clientY - rect.top) / rect.height - 0.5) * 26
    }
    const tick = () => {
      cx += (tx - cx) * 0.06
      cy += (ty - cy) * 0.06
      node.style.setProperty('--mx', `${cx.toFixed(2)}px`)
      node.style.setProperty('--my', `${cy.toFixed(2)}px`)
      frame = requestAnimationFrame(tick)
    }
    node.addEventListener('pointermove', onMove)
    frame = requestAnimationFrame(tick)
    return () => {
      cancelAnimationFrame(frame)
      node.removeEventListener('pointermove', onMove)
    }
  }, [reduced])

  useEffect(() => {
    if (sheet?.id) setOpenId(sheet.id)
  }, [sheet?.id, sheet?.at])

  /* Type anywhere on Today and the words land in the line. */
  useEffect(() => {
    const onKey = (event) => {
      if (openRef.current) return
      if (event.metaKey || event.ctrlKey || event.altKey || event.key.length !== 1 || inputActive()) return
      event.preventDefault()
      box.current?.focus()
      setDraft((current) => current + event.key)
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [])

  function remember(next) {
    posesRef.current = next
    setPoses(next)
    localStorage.setItem(POSE_KEY, JSON.stringify(next))
  }

  function poseFor(id, index) {
    return poses[id] || paperPose(id, index, papers.length, compact)
  }

  function save(event) {
    event?.preventDefault()
    const text = draft.trim()
    if (!text) return
    let note
    commit((state) => {
      const result = captureThought(state, text)
      note = result.note
      return result.state
    })
    if (note) setFreshId(note.id)
    setDraft('')
    if (box.current) box.current.style.height = ''
  }

  function addStep(event) {
    event.preventDefault()
    const text = stepDraft.trim().replace(/\s*\n\s*/g, ' ')
    if (!text || preview) return
    commit((state) => ({ ...state, notes: appendNextStep(state.notes, text, today || localDateKey()) }))
    setStepDraft('')
  }

  function toggleStep(step) {
    if (preview) return
    commit((state) => ({ ...state, notes: toggleNextStep(state.notes, step) }))
    if (step.done) return
    setGhosts((current) => new Set(current).add(step.id))
    window.setTimeout(() => setGhosts((current) => {
      const next = new Set(current)
      next.delete(step.id)
      return next
    }), 1400)
  }

  /* Opening and setting down morph the paper into the sheet and back. */
  function transition(paper, update) {
    if (reduced || !document.startViewTransition) {
      update()
      return
    }
    if (paper) paper.style.viewTransitionName = 'open-paper'
    const run = document.startViewTransition(() => {
      if (paper) paper.style.viewTransitionName = ''
      flushSync(update)
    })
    run.finished.finally(() => { if (paper) paper.style.viewTransitionName = '' })
  }

  function openNote(id, paper = null) {
    transition(paper, () => setOpenId(id))
  }

  function closeSheet() {
    const id = openRef.current
    const paper = id ? stage.current?.querySelector(`[data-paper="${CSS.escape(id)}"]`) : null
    if (reduced || !document.startViewTransition) {
      setOpenId(null)
      onSheetDone?.()
      return
    }
    const run = document.startViewTransition(() => {
      if (paper) paper.style.viewTransitionName = 'open-paper'
      flushSync(() => setOpenId(null))
    })
    onSheetDone?.()
    run.finished.finally(() => { if (paper) paper.style.viewTransitionName = '' })
  }

  function dragPaper(event, id, index) {
    if (event.button !== 0) return
    const paper = event.currentTarget
    const bounds = stage.current?.getBoundingClientRect()
    if (!bounds?.width || !paper) return
    // Phones stack the papers in flow: a tap opens one, a swipe scrolls the page.
    const scatter = getComputedStyle(paper).position === 'absolute'
    const origin = poseFor(id, index)
    const startX = event.clientX
    const startY = event.clientY
    let moved = false
    if (scatter) paper.setPointerCapture?.(event.pointerId)
    const move = (ev) => {
      const dx = ev.clientX - startX
      const dy = ev.clientY - startY
      if (!moved && Math.hypot(dx, dy) <= 4) return
      if (!scatter) { moved = true; return }
      if (!moved) setHeldId(id)
      moved = true
      const next = {
        ...posesRef.current,
        [id]: clampPose({ x: origin.x + dx / bounds.width, y: origin.y + dy / bounds.height, rot: origin.rot }),
      }
      posesRef.current = next
      setPoses(next)
    }
    const up = (ev) => {
      window.removeEventListener('pointermove', move)
      window.removeEventListener('pointerup', up)
      window.removeEventListener('pointercancel', up)
      setHeldId(null)
      if (moved && scatter) localStorage.setItem(POSE_KEY, JSON.stringify(posesRef.current))
      else if (!moved && ev.type === 'pointerup') openNote(id, paper)
    }
    window.addEventListener('pointermove', move)
    window.addEventListener('pointerup', up)
    window.addEventListener('pointercancel', up)
  }

  const nowAt = ribbonAt(now)

  return (
    <div className={`spread ${arrived ? '' : 'is-arriving'} ${sheetNote ? 'is-open' : ''}`} data-phase={phase}>
      <section className="day-page" aria-label="Today">
        <header className="day-head">
          <p className="day-date">{DATE.format(new Date(`${today}T12:00:00`))}</p>
          <h1>{greeting}</h1>
          <p className="day-sub">{sub}</p>
        </header>

        <form className="day-line" onSubmit={save}>
          <label className="visually-hidden" htmlFor="day-line">Leave a thought</label>
          <textarea
            id="day-line"
            ref={box}
            rows={1}
            value={draft}
            placeholder="Leave a thought here."
            onChange={(event) => {
              setDraft(event.target.value)
              const el = event.target
              el.style.height = 'auto'
              el.style.height = `${Math.min(el.scrollHeight, 180)}px`
            }}
            onKeyDown={(event) => {
              if (event.key === 'Enter' && !event.shiftKey) {
                event.preventDefault()
                save(event)
              }
            }}
          />
          <button type="submit" aria-label="Leave it on the desk" disabled={!draft.trim()}>
            <ArrowBendDownLeft weight="bold" />
          </button>
          <p className="day-line-hint">{draft.trim() ? 'Return sets it on the desk · Shift-Return for a new line' : 'Type anywhere. It becomes a note on the desk.'}</p>
        </form>

        <section className="day-section" aria-labelledby="day-next">
          <h2 id="day-next">Next <small>{openCount ? `${openCount} open` : ''}</small></h2>
          {steps.length > 0 && (
            <ul className="day-steps">
              {steps.slice(0, 5).map((step) => (
                <li key={step.id} className={step.done ? 'is-done' : ''}>
                  <button type="button" className="day-check" aria-label={`${step.done ? 'Reopen' : 'Complete'} ${step.text}`} aria-pressed={step.done} disabled={preview} onClick={() => toggleStep(step)}>
                    <Check weight="bold" />
                  </button>
                  <button type="button" className="day-step-text" onClick={() => openNote(step.noteId)}>
                    <span>{step.text}</span>
                    {step.noteId !== planId && <small>{step.noteTitle}</small>}
                  </button>
                </li>
              ))}
            </ul>
          )}
          {!steps.length && <p className="day-empty">Nothing waiting. Add one small thing, or leave the list empty.</p>}
          {!preview && (
            <form className="next-add" onSubmit={addStep}>
              <Plus />
              <label className="visually-hidden" htmlFor="next-add">Add a next step</label>
              <input id="next-add" value={stepDraft} maxLength={240} placeholder="Add a next step" onChange={(event) => setStepDraft(event.target.value)} />
            </form>
          )}
        </section>

        <section className="day-section" aria-labelledby="day-today">
          <h2 id="day-today">Today <small>{events.length ? `${events.length} planned` : ''}</small></h2>
          <div className="ribbon" aria-hidden="true">
            <div className="ribbon-track"><span style={{ width: `${nowAt * 100}%` }} /></div>
            {events.map((event) => (
              <i key={event.id} className="ribbon-event" style={{ left: `${ribbonAt(new Date(event.start)) * 100}%` }} />
            ))}
            <b className="ribbon-now" style={{ left: `${nowAt * 100}%` }} />
            {HOURS.map(([label, hour]) => (
              <small key={label} style={{ left: `${((hour - 6) / 18) * 100}%` }}>{label}</small>
            ))}
          </div>
          {events.length > 0 ? (
            <ul className="today-events">
              {events.map((event) => (
                <li key={event.id}>
                  <button type="button" className={Date.parse(event.start) < now.getTime() ? 'is-past' : ''} onClick={() => navigate('Calendar', { date: today })}>
                    <time dateTime={event.start}>{timeLabel(event.start)}</time>
                    <span>{event.title}</span>
                  </button>
                </li>
              ))}
            </ul>
          ) : (
            <p className="day-empty">Nothing on the calendar. <button type="button" onClick={() => navigate('Calendar', { date: today })}>Plan something</button></p>
          )}
        </section>

        <section className="day-section day-journal" aria-labelledby="day-page">
          <h2 id="day-page">{late ? 'Tonight’s page' : 'Today’s page'}</h2>
          <button type="button" onClick={() => navigate('Journal')}>
            <span>{journal ? excerpt(journal.markdown, 140) || 'A page is started.' : 'How are you, really?'}</span>
            <em>{journal ? 'Keep writing' : 'Open the journal'} <ArrowRight /></em>
          </button>
        </section>

        <footer className="day-links">
          <button type="button" onClick={() => navigate('Assistant', { prompt: 'I want to untangle what is on my mind. Ask one question at a time.' })}>Talk it through</button>
          <button type="button" onClick={() => setFocusOpen(true)}>Twenty-five quiet minutes</button>
          <button type="button" onClick={() => navigate('Sky')}>See the sky</button>
        </footer>
      </section>

      <section className="desk" aria-label="The desk">
        <div className="desk-light" aria-hidden="true" />
        <header className="desk-head">
          <h2>On the desk</h2>
          <span>{papers.length < notes.length ? `${papers.length} of ${notes.length} notes` : `${notes.length} ${notes.length === 1 ? 'note' : 'notes'}`}</span>
          {Object.keys(poses).length > 0 && <button type="button" onClick={() => remember({})}>Tidy</button>}
          <button type="button" onClick={() => navigate('Notes')}>All notes <ArrowRight /></button>
        </header>
        <div className="desk-stage" ref={stage}>
          {papers.map((note, index) => {
            const pose = poseFor(note.id, index)
            return (
              <article
                key={note.id}
                data-paper={note.id}
                className={`paper ${freshId === note.id ? 'is-fresh' : ''} ${heldId === note.id ? 'is-held' : ''} ${preview ? 'is-sample' : ''}`}
                style={{ left: `${pose.x * 100}%`, top: `${pose.y * 100}%`, '--rot': `${pose.rot}deg`, '--i': index }}
                onPointerDown={(event) => dragPaper(event, note.id, index)}
                onKeyDown={(event) => {
                  if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault()
                    openNote(note.id, event.currentTarget)
                  }
                }}
                tabIndex={0}
                role="button"
                aria-label={`Open ${note.title}`}
              >
                <small>
                  {note.pinned && <PushPin weight="fill" />}
                  {note.tags?.[0] ? `#${note.tags[0]}` : 'A thought'}
                </small>
                <strong>{note.title}</strong>
                <p>{excerpt(paperFields(note).body, 120).replace(/☐/g, '○')}</p>
              </article>
            )
          })}
          {!papers.length && (
            <div className="desk-clear">
              <p>The desk is clear.</p>
              <span>Type anything and it lands here.</span>
              {!sampled && <button type="button" onClick={() => onKeep()}>Or lay out a sample room</button>}
            </div>
          )}
        </div>
        <FieldBanner preview={preview} sampled={sampled} onKeep={() => onKeep()} onBlank={onBlank} onRemove={onRemove} />
        {sheetNote && (
          <FieldSheet
            note={sheetNote}
            preview={preview}
            onClose={closeSheet}
            onCommit={(id, patch) => commit((state) => updateNote(state, id, patch))}
            onKeep={onKeep}
            onOpenNotes={() => { setOpenId(null); onSheetDone?.(); navigate('Notes', { noteId: sheetNote.id }) }}
          />
        )}
      </section>

      {focusOpen && (
        <FocusEnvironment
          session={workspace.focus}
          task={steps.find((step) => !step.done)?.text}
          onChange={(focus) => commit((state) => ({ ...state, focus }))}
          close={() => setFocusOpen(false)}
        />
      )}
    </div>
  )
}
