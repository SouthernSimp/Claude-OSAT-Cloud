import { useEffect, useState } from 'react'
import {
  BookOpenText,
  CaretDown,
  CurrencyDollar,
  Files,
  FolderSimple,
  GearSix,
  ListChecks,
  MagnifyingGlass,
  Moon,
  MoonStars,
  Plus,
  SquaresFour,
  Sun,
  Tray,
  UploadSimple,
} from '@phosphor-icons/react'

import { Menu } from '../lib/Menu.jsx'

const TABS = [
  ['Today', 'Today'],
  ['Notes', 'Notes'],
  ['Mindmap', 'Mindmap'],
  ['Journal', 'Journal'],
  ['Calendar', 'Calendar'],
  ['Assistant', 'Local AI'],
]

const MORE = [
  ['Sky', 'Sky', MoonStars],
  ['Projects', 'Projects', FolderSimple],
  ['Habits', 'Habits', ListChecks],
  ['Reflection', 'Reflect', BookOpenText],
  ['Budget', 'Money', CurrencyDollar],
  ['Files', 'Files', Files],
  ['Inbox', 'Inbox', Tray],
  ['Obsidian', 'Obsidian', UploadSimple],
  ['Settings', 'Settings', GearSix],
  ['More', 'All spaces', SquaresFour],
]

export function useReducedMotion() {
  const [reduced, setReduced] = useState(() => window.matchMedia('(prefers-reduced-motion: reduce)').matches)
  useEffect(() => {
    const media = window.matchMedia('(prefers-reduced-motion: reduce)')
    const onChange = () => setReduced(media.matches)
    media.addEventListener('change', onChange)
    return () => media.removeEventListener('change', onChange)
  }, [])
  return reduced
}

/* One bar for every view. The active tab's pill carries a view-transition
   name, so navigating glides it to the next tab instead of blinking. */
export function FieldTopbar({ view, navigate, storage, onCommands, onCapture, onTheme }) {
  const extra = MORE.find(([id]) => id === view)
  const pill = <span className="topbar-pill" aria-hidden="true" />
  return (
    <header className="topbar">
      <div className="topbar-start">
        <button type="button" className="wordmark" onClick={() => navigate('Today')}>OSAT</button>
        <span className={`topbar-saved ${storage.status}`} title={storage.message}>
          <i />
          {storage.status === 'error' ? 'Check storage' : 'On this Mac'}
        </span>
      </div>
      <nav className="topbar-tabs" aria-label="Workspace">
        {TABS.map(([id, label], index) => (
          <button key={id} type="button" title={`${label}  ⌘${index + 1}`} aria-current={view === id ? 'page' : undefined} onClick={() => navigate(id)}>
            {view === id && pill}
            <span>{label}</span>
          </button>
        ))}
        <Menu
          align="end"
          className="topbar-more"
          ariaLabel="More spaces"
          items={MORE.map(([id, label, icon]) => ({ label, icon, checked: view === id, onSelect: () => navigate(id) }))}
          trigger={({ toggle, open }) => (
            <button type="button" aria-haspopup="menu" aria-expanded={open} aria-current={extra ? 'page' : undefined} onClick={toggle}>
              {extra && pill}
              <span>{extra ? extra[1] : 'More'}</span>
              <CaretDown weight="bold" />
            </button>
          )}
        />
      </nav>
      <div className="topbar-end">
        <button type="button" className="topbar-search" onClick={onCommands}>
          <MagnifyingGlass />
          <span>Search</span>
          <kbd>⌘K</kbd>
        </button>
        <button type="button" className="topbar-icon topbar-new" aria-label="New thought" title="New thought (N)" onClick={onCapture}>
          <Plus weight="bold" />
        </button>
        <button type="button" className="topbar-icon" aria-label="Switch light or dark appearance" onClick={onTheme}>
          <Sun className="sun-icon" />
          <Moon className="moon-icon" />
        </button>
      </div>
    </header>
  )
}

export function FieldBanner({ preview, sampled, onKeep, onBlank, onRemove }) {
  if (preview) {
    return (
      <div className="field-banner" role="status">
        <p>A sample room, so you can see the shape of it. Nothing is saved yet.</p>
        <button type="button" className="primary-button" onClick={onKeep}>Keep this room</button>
        <button type="button" onClick={onBlank}>Start blank</button>
      </div>
    )
  }
  if (!sampled) return null
  return (
    <div className="field-banner field-banner-quiet">
      <p>Sample notes are mixed in with yours.</p>
      <button type="button" onClick={onRemove}>Remove the samples</button>
    </div>
  )
}
