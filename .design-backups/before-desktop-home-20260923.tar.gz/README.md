# OSAT Field (copy)

A copy of the OSAT Field prototype, redesigned on September 23. The original OSAT Field folder, OSAT V2, and the installed apps are untouched, and this copy keeps its own browser data.

Double-click **Open OSAT Field.command**. It opens a private preview at http://127.0.0.1:5239/.

Today is a spread. The left page is the day: a line to leave a thought, the next steps from every note, a ribbon of the day with the calendar on it, and tonight's journal page. The right page is the desk, where your pinned and most recent notes lie as papers. Drag them where you like, or open one and it becomes a sheet you can write on. Type anywhere on Today and the words land in the line.

Notes, Mindmap, Journal, Calendar and Local AI sit in the bar across the top (⌘1–⌘6). Sky, projects, habits, money, files and settings are under **More**. On a phone the bar moves to the bottom.

An empty desk shows a sample room first. Nothing in that sample is saved until you choose **Keep this room**.
